---
name: cms-release-check
description: 临时上线验收，完成后删除
---

# 后台上线验收

仅验证上传、发布和下载。
